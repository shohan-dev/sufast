# 🚀 sufast – A Blazing Fast Python Web Framework Powered by Rust 

**sufast** is a hybrid Python web framework that combines the **developer simplicity of Python** with the **performance of Rust**. Inspired by FastAPI, `sufast` delivers high-speed route handling and low-latency response times using a Rust backend while allowing full flexibility via Python.

Perfect for:
- High-performance microservices ⚡
- Real-time APIs 🚦
- Custom dynamic route handling 🔄
- Python + Rust FFI enthusiasts 🧠


## 📦 Installation

```bash
pip install sufast
```
⚠️ Requires Python 3.8+ and a platform-compatible Rust binary bundled in the package.

# 🚀 Quickstart

```bash
from sufast import App

app = App()

@app.get("/")
def hello():
    return {"message": "Hello from sufast 👋"}

app.run()
```
Visit: http://localhost:8080/ 🚀


# 📚 Advanced Example – API Server
```bash
from sufast import App

app = App()

# 🧪 Sample database
users = {
    "shohan": {"name": "shohan", "email": "shohan@example.com"},
    "bob": {"name": "Bob", "email": "bob@example.com"},
    "alice": {"name": "Alice", "email": "alice@example.com"},
}

@app.get("/")
def home():
    return {"message": "Welcome to sufast API 🚀"}

@app.get("/shohan")
def app_info():
    return {"message": "Built by Shohan – Power of Rust & Python ⚙️🐍"}

@app.get("/users")
def get_users():
    return {"users": users}

@app.post("/users")
def show_user():
    # This is a mocked POST example
    return {
        "data": users["bob"]
    }

app.run()
```

# 🔬 Load Testing with k6
```bash
// test.js
import http from 'k6/http';
import { check, sleep } from 'k6';

export let options = {
  vus: 100,
  duration: '10s',
};

export default function () {
  let res = http.get('http://localhost:8080');

  check(res, {
    'status is 200': (r) => r.status === 200,
    'response has message': (r) => r.json().message !== undefined,
  });

  sleep(0.001);
}
```

Run the test:
```bash
k6 run test.js
```

# ✨ Features

✅ Rust-based core for high-speed routing

✅ Python decorators like @app.get() / @app.post()

✅ FastAPI-style route syntax

✅ Clean, readable API for rapid prototyping

✅ Modular architecture for production use



# 🔭 Roadmap

 🧠 Static parameters (like /users)

 🌐 Static file serving

 🐳 Docker support

 📄 PyPI full release and documentation site

🤝 Contributing
Found a bug or want to help?
Open an issue or PR on GitHub!

📃 License
MIT License – do anything you want, just give credit 😄
Copyright © Shohan

# sufast: Python ❤️ Rust – the future of high-performance web APIs.


